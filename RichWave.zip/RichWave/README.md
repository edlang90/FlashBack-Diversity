# RichWave
A Arduino library to control the RTC6715 RichWave 5.8 GHz RX Chip.
This chip is commonly used in Foxtech/Boscam Receiver modules for example the RX5808 which is in turn is used
inside receivers like the RC305 or can be used stand-alone.
